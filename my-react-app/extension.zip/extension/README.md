# how to use it 

1. clone this "https://github.com/TrueGuardianAI/extension"

2  Go to chrome

3. On developer mode

4. go to extensions 

5 upload the downloaded extension folder.



